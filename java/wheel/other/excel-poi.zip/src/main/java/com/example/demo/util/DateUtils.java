package com.example.demo.util;

import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.poi.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 时间工具类
 *
 * @author xuzhuohao
 */
public class DateUtils {
	public static String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static String DATE_FORMAT_CHINESE = "yyyy年M月d日";
	public static String DATE_FORMAT = "yyyy-MM-dd";
    /**
     * 添加方法，时间转换
     *
     * @param resultType 转换的结果类型，对象需要拥有需要 valueOf(String) 方法
     * @param date       日期
     * @param format     格式化格式
     * @param <T>        结果泛型
     * @return 返回格式化后结果
     */
    public static <T> T getDateFormat(Class<T> resultType, Date date, String format) {
        SimpleDateFormat sf = new SimpleDateFormat(format);
        try {
            if (resultType.equals(String.class)) {
                return (T) sf.format(date);
            }
            Method method = resultType.getMethod("valueOf", String.class);
            final Object result = method.invoke(null, sf.format(date));
            return (T) result;
        } catch (Exception e) {
            throw new RuntimeException("时间转换异常：" + e);
        }
    }

    /**
     * 时间计算
     * @param date 时间
     * @param add 增加的值(可以输入负数)
     * @param unit 单位： yyyy 年， MM 月， dd 日， HH 小时， mm 分钟， ss 秒
     * @return
     */
    public static Date getDateCalculate(Date date, int add, String unit){
        SimpleDateFormat sf = new SimpleDateFormat(unit);
        int unitNumber = Integer.valueOf(sf.format(date));
        unitNumber += add;
        sf = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
        final int i = "yyyyMMdd HH:mm:ss".indexOf(unit);
        String formatDate = sf.format(date);
        formatDate = formatDate.substring(0, i) + unitNumber + formatDate.substring(i+unit.length());
        try {
            return sf.parse(formatDate);
        } catch (ParseException e) {
            throw new RuntimeException("时间计算异常：" + e.getLocalizedMessage());
        }
    }

    public static Date getDate(String dateStr, String format){
        SimpleDateFormat sf = new SimpleDateFormat(format);
        try {
            return sf.parse(dateStr);
        } catch (ParseException e) {
            throw new RuntimeException("日期转换失败!");
        }
    }
    

	public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	public static final String YYYY_MM_DD_HH_MM= "yyyy-MM-dd HH:mm";
	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	public static final String HH_MM = "HH:mm";
	public static final String yyyyMMdd = "yyyyMMdd";
	public static final String yyyyMMddHHmmss = "yyyyMMddHHmmss";
//	public static final String YYYYMMDDhhmmss = "YYYYMMDDhhmmss";
	
	// 以毫秒表示的时间
	private static final long DAY_IN_MILLIS = 24 * 3600 * 1000;
	private static final long HOUR_IN_MILLIS = 3600 * 1000;
	private static final long MINUTE_IN_MILLIS = 60 * 1000;
	private static final long SECOND_IN_MILLIS = 1000;


	private static Logger log = LoggerFactory.getLogger(DateUtils.class);


	/**
	 * 当前日历，这里用中国时间表示
	 * 
	 * @return 以当地时区表示的系统当前日历
	 */
	public static Calendar getCalendar() {
		return Calendar.getInstance();
	}

	/**
	 * 指定毫秒数表示的日历
	 * 
	 * @param millis
	 *            毫秒数
	 * @return 指定毫秒数表示的日历
	 */
	public static Calendar getCalendar(long millis) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date(millis));
		return cal;
	}

	/**
	 * 当前日期
	 * 
	 * @return 系统当前时间
	 */
	public static Date getDate() {
		return new Date();
	}

	/**
	 * 指定毫秒数表示的日期
	 * 
	 * @param millis
	 *            毫秒数
	 * @return 指定毫秒数表示的日期
	 */
	public static Date getDate(long millis) {
		return new Date(millis);
	}


	
	

	public static String date2str(Date date) {
		String str = "";
		if(null!=date){
	        try{
	    		SimpleDateFormat dateFormat = new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS, Locale.PRC);
	    		str = dateFormat.format(date);
			}catch(Exception e){
				e.printStackTrace();  
				log.error("date2str 日期" + date + "换字符 " + YYYY_MM_DD_HH_MM_SS + "错误");
			}
		}
        return str;
	}
	


	public static String getCurrentDateString( String fmt) {
		String str = "";
        try{
    		SimpleDateFormat dateFormat = new SimpleDateFormat(fmt, Locale.PRC);
    		str = dateFormat.format(new Date());
		}catch(Exception e){
			e.printStackTrace();  
			log.error("date2str 日期" + str + "换字符 " + fmt + "错误");
		}
        return str;
	}
	
	

	/**
	 * 格式化时间
	 * 
	 * @param data
	 * @param format
	 * @return
	 */
	public static String dataformat(String data, String format) {
		SimpleDateFormat sformat = new SimpleDateFormat(format);
		Date date = null;
		try {
			date = sformat.parse(data);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sformat.format(date);
	}




	/**
	 * 指定毫秒数的时间戳
	 * 
	 * @param millis
	 *            毫秒数
	 * @return 指定毫秒数的时间戳
	 */
	public static Timestamp getTimestamp(long millis) {
		return new Timestamp(millis);
	}

	/**
	 * 以字符形式表示的时间戳
	 * 
	 * @param time
	 *            毫秒数
	 * @return 以字符形式表示的时间戳
	 */
	public static Timestamp getTimestamp(String time) {
		return new Timestamp(Long.parseLong(time));
	}

	/**
	 * 系统当前的时间戳
	 * 
	 * @return 系统当前的时间戳
	 */
	public static Timestamp getTimestamp() {
		return new Timestamp(new Date().getTime());
	}

	/**
	 * 指定日期的时间戳
	 * 
	 * @param date
	 *            指定日期
	 * @return 指定日期的时间戳
	 */
	public static Timestamp getTimestamp(Date date) {
		return new Timestamp(date.getTime());
	}

	/**
	 * 指定日历的时间戳
	 * 
	 * @param cal
	 *            指定日历
	 * @return 指定日历的时间戳
	 */
	public static Timestamp getCalendarTimestamp(Calendar cal) {
		return new Timestamp(cal.getTime().getTime());
	}

	public static Timestamp gettimestamp() {
		Date dt = new Date();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String nowTime = df.format(dt);
		Timestamp buydate = Timestamp.valueOf(nowTime);
		return buydate;
	}

	// ////////////////////////////////////////////////////////////////////////////
	// getMillis
	// 各种方式获取的Millis
	// ////////////////////////////////////////////////////////////////////////////

	/**
	 * 系统时间的毫秒数
	 * 
	 * @return 系统时间的毫秒数
	 */
	public static long getMillis() {
		return new Date().getTime();
	}

	/**
	 * 指定日历的毫秒数
	 * 
	 * @param cal
	 *            指定日历
	 * @return 指定日历的毫秒数
	 */
	public static long getMillis(Calendar cal) {
		return cal.getTime().getTime();
	}

	/**
	 * 指定日期的毫秒数
	 * 
	 * @param date
	 *            指定日期
	 * @return 指定日期的毫秒数
	 */
	public static long getMillis(Date date) {
		return date.getTime();
	}

	/**
	 * 指定时间戳的毫秒数
	 * 
	 * @param ts
	 *            指定时间戳
	 * @return 指定时间戳的毫秒数
	 */
	public static long getMillis(Timestamp ts) {
		return ts.getTime();
	}





	/**
	 * 计算两个时间之间的差值，根据标志的不同而不同
	 * 
	 * @param flag
	 *            计算标志，表示按照年/月/日/时/分/秒等计算
	 * @param calSrc
	 *            减数
	 * @param calDes
	 *            被减数
	 * @return 两个日期之间的差值
	 */
	public static int dateDiff(char flag, Calendar calSrc, Calendar calDes) {

		long millisDiff = getMillis(calSrc) - getMillis(calDes);

		if (flag == 'y') {
			return (calSrc.get(calSrc.YEAR) - calDes.get(calDes.YEAR));
		}

		if (flag == 'd') {
			return (int) (millisDiff / DAY_IN_MILLIS);
		}

		if (flag == 'h') {
			return (int) (millisDiff / HOUR_IN_MILLIS);
		}

		if (flag == 'm') {
			return (int) (millisDiff / MINUTE_IN_MILLIS);
		}

		if (flag == 's') {
			return (int) (millisDiff / SECOND_IN_MILLIS);
		}

		return 0;
	}

	public static int getYear() {
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(getDate());
		return calendar.get(Calendar.YEAR);
	}

	public static int getMonth() {
		// int month = currTime.getMonth()+1
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(getDate());
		return (calendar.get(Calendar.MONTH)) + 1;
	}

	/**
	 * 获取每天的开始时间 00:00:00:00
	 * 
	 * @param date
	 * @return
	 */
	public static Date getStartTime(Date date) {
		Calendar dateStart = Calendar.getInstance();
		dateStart.setTime(date);
		dateStart.set(Calendar.HOUR_OF_DAY, 0);
		dateStart.set(Calendar.MINUTE, 0);
		dateStart.set(Calendar.SECOND, 0);
		dateStart.set(Calendar.MILLISECOND, 0);
		return dateStart.getTime();
	}

	/**
	 * 获取每天的开始时间 23:59:59:999
	 * 
	 * @param date
	 * @return
	 */
	public static Date getEndTime(Date date) {
		Calendar dateEnd = Calendar.getInstance();
		dateEnd.setTime(date);
		dateEnd.set(Calendar.HOUR_OF_DAY, 23);
		dateEnd.set(Calendar.MINUTE, 59);
		dateEnd.set(Calendar.SECOND, 59);
		dateEnd.set(Calendar.MILLISECOND, 999);
		return dateEnd.getTime();
	}

	/**
	 * 返回指定年月的月的第一天
	 * 
	 * @param date
	 * @return
	 */
	public static Date getFirstDayOfMonth(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		return calendar.getTime();
	}

	/**
	 * 返回指定年月的月的最后一天
	 *
	 * @param date
	 * @return
	 */
	public static Date getLastDayOfMonth(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		return calendar.getTime();
	}
}
