package com.example.demo;

import com.example.demo.util.ExcelUtil;
import com.example.demo.util.Pojo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {

    @Test
    public void contextLoads() {
        List<Pojo> list = new ArrayList<>();
        final Pojo e = new Pojo();
        e.setId("1");
        e.setName("name");
        list.add(e);
        final Pojo e2 = new Pojo();
        e2.setId("1");
        e2.setName("name");
        list.add(e2);

        final ExcelUtil<Pojo> pojoExcelUtil = new ExcelUtil<Pojo>(Pojo.class);
        pojoExcelUtil.exportExcel(list,"sheetName");
    }

}
